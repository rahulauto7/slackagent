# FollowThrough — Judge Packet

**The Slack agent that never drops the ball.** Decisions and commitments become
first-class objects with a full lifecycle: capture → register → chase →
complete → recall → briefing → MCP.

## Contents

| File | What it is |
|---|---|
| `FollowThrough-project-story.pdf` | Full project story: what it does, how it's built, challenges |
| `architecture-diagram.png` | System architecture (Bolt Socket Mode + SQLite + cron + MCP, single process) |
| `thumbnail.png` | Feature overview visual |
| `demo-script.md` | Shot-by-shot script of the demo video |

## Links

- **Code:** https://github.com/rahulauto7/slackagent
- **Slack sandbox:** https://followthru-workspace.slack.com/
  (shared with testing@devpost.com and slackhack@salesforce.com)

## Try it in 60 seconds

1. Mention `@FollowThrough` on any thread → it extracts decisions + commitments
   and posts a summary card.
2. Check the channel canvas → a synced register of decisions, open commitments
   (overdue flagged ⚠️), and done items.
3. Open the assistant pane and ask *"What did we decide about pricing and why?"*
   → cited answer from the decision log only, with permalinks.
4. Say *"I'm on leave July 14–16"* → nudges reschedule to your return, the
   channel gets an at-risk flag, and the canvas gains an Out-of-office section.

## Quality

- 101 offline vitest tests (faked Slack, faked LLM, in-memory SQLite)
- Live smoke suites for LLM extraction and leave intent
- End-to-end live verifier for the leave lifecycle
